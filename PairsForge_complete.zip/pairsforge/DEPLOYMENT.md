# PairsForge — Deployment Guide

## Project Structure

```
pairsforge/
├── backend/
│   ├── main.py            ← FastAPI app (yfinance + Kalman + EG coint)
│   ├── requirements.txt
│   └── render.yaml        ← Render.com deploy config
└── frontend/
    ├── src/
    │   ├── App.jsx        ← Full React app
    │   └── main.jsx
    ├── index.html
    ├── package.json
    ├── vite.config.js
    └── vercel.json        ← Vercel deploy config
```

---

## Step 1 — Deploy the Backend on Render (free)

1. **Push your code to GitHub**
   ```bash
   git init
   git add .
   git commit -m "PairsForge initial"
   gh repo create pairsforge --public --push
   ```

2. **Go to [render.com](https://render.com)** → Sign up (free) → New → Web Service

3. **Connect your GitHub repo**, select the `backend/` folder as root directory

4. Set these fields:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - **Environment:** Python 3.11

5. Click **Deploy** — Render gives you a URL like:
   `https://pairsforge-api.onrender.com`

6. **Test it:** Open `https://pairsforge-api.onrender.com/health`
   → Should return `{"status": "ok"}`

   Also test: `https://pairsforge-api.onrender.com/api/prices?ticker1=AAPL&ticker2=MSFT&period=1y`

> ⚠️ Free Render services sleep after 15 min of inactivity. Upgrade to Starter ($7/mo) for always-on.

---

## Step 2 — Deploy the Frontend on Vercel (free)

1. **Edit `frontend/vercel.json`** — replace the placeholder with your real Render URL:
   ```json
   {
     "env": {
       "VITE_API_URL": "https://pairsforge-api.onrender.com"
     }
   }
   ```

2. **Go to [vercel.com](https://vercel.com)** → Sign up (free) → New Project

3. **Import your GitHub repo**, set **Root Directory** to `frontend/`

4. Vercel auto-detects Vite. Click **Deploy**.

5. Your app is live at: `https://pairsforge.vercel.app` (or your project name)

---

## Step 3 — Custom Domain (optional, ~$10-15/year)

1. Buy a domain at [Namecheap](https://namecheap.com) or [Cloudflare](https://cloudflare.com/products/registrar/) (cheapest)

2. In Vercel dashboard → your project → **Domains** → Add domain

3. Follow Vercel's DNS instructions (usually add a CNAME record)

4. Done — your app runs at `yourdomain.com` with free HTTPS

---

## Running Locally

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
# API docs: http://localhost:8000/docs
```

### Frontend
```bash
cd frontend
npm install
# For local dev pointing to local backend:
VITE_API_URL=http://localhost:8000 npm run dev
# Open http://localhost:5173
```

---

## API Reference

### `GET /api/prices`
Fetch raw price data.
```
?ticker1=AAPL&ticker2=MSFT&period=2y
```

### `POST /api/backtest`
Run full backtest.
```json
{
  "ticker1": "AAPL",
  "ticker2": "MSFT",
  "period": "2y",
  "lookback": 60,
  "entry_z": 2.0,
  "exit_z": 0.5,
  "stop_z": 3.5,
  "hedge_method": "kalman"   // or "ols"
}
```

### `GET /health`
Health check.

---

## Strategy Details

### Engle-Granger Cointegration
- Tests whether two log-price series share a long-run equilibrium
- Uses `statsmodels.tsa.stattools.coint` for the two-step EG test
- ADF test run on the resulting spread to confirm stationarity

### Kalman Filter Hedge Ratio
- State-space model: `log(Y) = β·log(X) + α + ε`
- β and α update each timestep via Kalman recursion
- Adapts to regime changes (unlike static OLS β)
- Process noise `δ = 1e-4` controls how fast β can drift

### Z-Score Signal
- Rolling mean/std over `lookback` window
- Entry: `|Z| > entry_z` → long or short the spread
- Exit: `|Z| < exit_z` → mean reversion complete
- Stop: `|Z| > stop_z` → cut loss if spread diverges

---

## Good Pairs to Try

| Pair | Sector | Notes |
|------|--------|-------|
| AAPL / MSFT | Tech | Classic liquid pair |
| KO / PEP | Beverages | Long-standing cointegration |
| GLD / SLV | Metals ETFs | Commodity-driven |
| XOM / CVX | Energy | Correlated to oil price |
| SPY / QQQ | ETFs | Market proxies |
| JPM / BAC | Banks | Rate-sensitive pair |
| WMT / TGT | Retail | Consumer staples |
